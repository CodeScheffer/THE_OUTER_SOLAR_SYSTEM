import matplotlib.pyplot as plt
import numpy as np

# steps
h = np.array([0.5, 0.25, 0.125, 0.0625, 0.03125, 0.015625, 0.0078125])

# errors
explicit_Euler = np.array([3.116e-01, 1.565e-01, 7.843e-02, 3.926e-02,
                           1.964e-02, 9.822e-03, 4.912e-03])

implicit_Euler = np.array([3.172e-01, 1.579e-01, 7.878e-02, 3.934e-02,
                           1.966e-02, 9.828e-03, 4.913e-03])

symplectic_Euler = np.array([5.329e-03, 2.665e-03, 1.333e-03, 6.665e-04,
                             3.332e-04, 1.666e-04, 8.331e-05])

stormer_verlet = np.array([5.178e-06, 1.295e-06, 3.236e-07, 8.091e-08,
                           2.023e-08, 5.057e-09, 1.262e-09])

yoshida_step = np.array([8.692e-12, 7.452e-12, 7.185e-12, 8.105e-12,
                          1.061e-11, 1.021e-11, 1.181e-11])

discrete_gradient = np.array([1.104e-05, 2.760e-06, 6.900e-07, 1.725e-07,
                              4.312e-08, 1.078e-08, 2.696e-09])

print(h)
print(explicit_Euler)
print(len(h), len(explicit_Euler))


# plot log-log
plt.figure(figsize=(8,6))

plt.loglog(h, explicit_Euler, 'o-', label='Explicit Euler')
plt.loglog(h, implicit_Euler, 's--', label='Implicit Euler')
plt.loglog(h, symplectic_Euler, '^-', label='Symplectic Euler')
plt.loglog(h, stormer_verlet, 'd-', label='Störmer–Verlet')
plt.loglog(h, yoshida_step, 'x-', label='Yoshida')
plt.loglog(h, discrete_gradient, 'p-', label='Discrete Gradient')

plt.xlabel(r'$h$')
plt.ylabel('Erro')
plt.legend()
plt.grid(True, which="both", ls="--", alpha=0.5)
plt.tight_layout()


def order_loglog(h, E):
    logh = np.log10(h)
    logE = np.log10(E)
    # polyfit return [slope, intercept]
    p, logC = np.polyfit(logh, logE, 1)
    return p

#order_p calculus
p_explicit = order_loglog(h, explicit_Euler)
p_implicit = order_loglog(h, implicit_Euler)
p_symplectic = order_loglog(h, symplectic_Euler)
p_stormer = order_loglog(h, stormer_verlet)
p_yoshida = order_loglog(h, yoshida_step)
p_discrete = order_loglog(h, discrete_gradient)

print("Ordem experimental p:")
print(f"Explicit Euler: {p_explicit:.3f}")
print(f"Implicit Euler: {p_implicit:.3f}")
print(f"Symplectic Euler: {p_symplectic:.3f}")
print(f"Störmer–Verlet: {p_stormer:.3f}")
print(f"Yoshida: {p_yoshida:.3f}")
print(f"Discrete Gradient: {p_discrete:.3f}")

