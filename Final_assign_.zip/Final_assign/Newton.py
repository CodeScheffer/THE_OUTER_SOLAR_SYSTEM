import numpy as np
from scipy.linalg import lu_factor, lu_solve

def APPROX_JACOBIAN(F, x):
    n = len(x) # n receive the lenght of x if x = [x1, x2, x3] n = 3
    J = np.zeros((n, n)) # create a jacobian matrix full of zeros, n lines andn rows
    eps0 = 1e-16 # machine precision
    delta = np.sqrt(eps0) * np.maximum(1.0, np.abs(x)) #the sqrt of machine precision is the step, 
    # which if we use it large, truncation erro domains, small the rownsdorff error domain, so, 
    # the best step is the balance between them which is the sqrt of machine precision times the 
    # maximum value (1.0 if x is small, and x iF x is large, so, the step can follow the order 
    # of magnetude)
    Fx = F(x)
    
    for j in range(n):
        x_temp = x.copy() # copy of x
        x_temp[j] = x_temp[j] + delta[j]
        Fj = F(x_temp)
        J[:, j] = (Fj - Fx)/delta[j]
    return J

def NEWTON(F, x0, TOL, MAX_ITER, DF=None, Simplified = 0):
    
    x = np.copy(x0)
    
    if Simplified == 1:
        J0 = DF(x0) if DF is not None else APPROX_JACOBIAN(F, x0)
        
        luj, pivj = lu_factor(J0)
        
        for k in range(MAX_ITER):
            Fx = F(x)
            delta_x = lu_solve((luj, pivj), -Fx)
            x = x + delta_x
            if np.linalg.norm(delta_x,2)<TOL:
                return x, k+1
        return x, MAX_ITER
    else:
        for k in range(MAX_ITER):
            Fx = F(x)
            
            if DF is not None:
                J =DF(x)
            else:
                J = APPROX_JACOBIAN(F, x)
            
            lu, piv = lu_factor(J)
            delta_x = lu_solve((lu, piv), -Fx)
            x = x + delta_x
            
            if np.linalg.norm(delta_x, 2) < TOL:
                return x, k+1
        return x, MAX_ITER
