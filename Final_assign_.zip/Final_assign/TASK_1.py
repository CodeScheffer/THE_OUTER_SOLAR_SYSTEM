import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
from Newton import NEWTON, APPROX_JACOBIAN
from scipy.integrate import solve_ivp

G = 2.95912208286 * 10**(-4) # Graviatational constant

masses = np.array([ # Mass
    1.00000597682, #m0, Sun + Inner planet
    0.000954786104043, # m1 Jupiter
    0.000285583733151, # m2 Saturn
    0.0000437273164546, #m3 Uranus
    0.0000517759138449, # m4 Neptune
    1/(1.3*10**8), # m5 Pluto
    ])

q_init = np.array([ # Positons
    [0.0, 0.0, 0.0], # Sun
    [-3.5023653, -3.8169847, -1.5507963], # Jupiter position
    [9.0755314, -3.0458353, -1.6483708], # Saturn Position
    [8.3101420, -16.2901086, -7.2521278], # Uranus position
    [11.4707666, -25.7294829, -10.8169456], # Neptune possition
    [-15.5387357, -25.2225594, -3.1902382], # Pluto position
    ])

v_init = np.array([ # Velcities
    [0.0, 0.0, 0.0], # Sun position
    [0.00565429, -0.00412490, -0.00190589], # Jupiter Velocity
    [0.00168318, 0.00483525, 0.00192462], # Saturn Velocity
    [0.00354178, 0.00137102, 0.00055029], # Uranus Velocity
    [0.00288930, 0.00114527, 0.00039677], # Neptune Velocity
    [0.00276725, -0.00170702, -0.00136504], # PLuto Velocit
    ])

p_init = masses[:, np.newaxis]*v_init # initial moment p = m*v

def Compute_Acc(q, masses, G): # calculate the \dot{p} = -\partial H/\partial q
    
    n = len(masses) # number os bodies
    dp = np.zeros_like(q) # same size as q, but fill of zeros
    
    for i in range(n): # double loop to calculate the iteration between bodiies
        for j in range(n):
            if i != j: # avoid the body to interact with itself
                r_ij = q[i] - q[j]
                dist = np.linalg.norm(r_ij) + 1e-12 # euclidian distance
                dp[i] += -G * masses[i] * masses[j] * r_ij / (dist**3)
    return dp

def compute_Vel(p, masses): # calculate de \dot{q} = \partial H/ \partial p
    
    return p/masses[:, np.newaxis]

def explicita_Euler(p, q, h, masses, G):
    
    dp = Compute_Acc(q, masses, G)
    dq = compute_Vel(p, masses)
    
    p_new = p+h*dp # explicit updates, pn+1 = pn + h \dot{pn}
    q_new = q+h*dq

    return p_new, q_new

def implicit_Euler(p,q,h, masses, G):
    
    n = len(masses) # number of bodies
    
    def F(x):
        
        p_new = x[:n*3].reshape(n,3) # extract pn+ from the first n*3 elements
        q_new = x[n*3:].reshape(n,3)
        
        dp_new = Compute_Acc(q_new, masses, G)
        dq_new = compute_Vel(p_new, masses)
        
        F_p = p_new - p - h*dp_new
        F_q = q_new - q - h*dq_new
        
        return np.concatenate([F_p.flatten(), F_q.flatten()]) # concatenate in a unique vector to be solved by Newton
    
    p_guess, q_guess = explicita_Euler(p, q, h, masses, G) # explicit euler step used as initial guess
    x0 = np.concatenate([p_guess.flatten(), q_guess.flatten()])
    
    x_sol,_ = NEWTON(F, x0, TOL=1e-8, MAX_ITER=100)
    
    p_new = x_sol[:n*3].reshape(n,3)
    q_new = x_sol[n*3:].reshape(n,3)
    
    return p_new, q_new

def Symplectic_Euler(p, q, h, masses, G): # explicit in p, but implicit in q

    dp = Compute_Acc(q, masses, G)
    p_new = p + h*dp

    dq_new = compute_Vel(p_new, masses)    
    q_new = q+h*dq_new
    
    return p_new, q_new

def stormer_verlet(p, q, h, masses, G):
    
    dp = Compute_Acc(q, masses, G) # half step in the momentum
    p_half = p+(h/2)*dp
    
    dq = compute_Vel(p_half, masses) # complete step in the position
    q_new = q + h*dq
    
    dp_new = Compute_Acc(q_new, masses, G) # 2nd half step in the momentum
    p_new = p_half + (h/2) * dp_new
    
    return p_new, q_new

def Simulate(method, h, T_final, p0,q0,masses, G):
    n_steps = int(T_final/h) + 1
    
    p = p0.copy()
    q = q0.copy()
    
    trajectories = np.zeros((n_steps, len(masses), 3))
    trajectories[0] = q
    
    for i in range(1,n_steps):
        p,q = method(p,q,h,masses,G)
        
        trajectories[i] = q
        
        if i% 1000 == 0 :
            print(f" steps {i}/{n_steps}") # print the progress in each 1000 iterations
    return trajectories

def plot_trajectories(trajectories, title, ax): #### 2D plot
    
    Planet_names = ['Sun', 'J', 'S', 'U', 'N', 'P']
    
    for i in range(1,6): # 6 planets
        ax.plot(trajectories[:,i,0], trajectories[:,i,1], linewidth = 0.5, alpha = 0.7)
    for i in range(6):
        ax.plot(trajectories[-1,i,0], trajectories[-1,i,1],'ko', markersize = 6)
        
        ax.text(trajectories[-1,i,0], trajectories[-1,i,1], f'  {Planet_names[i]}', fontsize = 10, fontweight = 'bold')
        
    ax.set_xlabel('x [AU]')
    ax.set_ylabel('y [AU]')
    ax.set_title(title)
    ax.axis('equal')
    ax.grid(True, alpha = 0.3)

# def plot_trajectories(trajectories, title, ax): # 3D plot
#     fig = plt.figure(figsize=(10, 8))
#     ax = fig.add_subplot(111, projection='3d')
    
#     Planet_names = ['Sun', 'J', 'S', 'U', 'N', 'P']
    
#     for i in range(1, 6):
#         ax.plot(trajectories[:, i, 0], 
#                 trajectories[:, i, 1], 
#                 trajectories[:, i, 2],
#                 linewidth=0.5, alpha=0.7)
    
#     for i in range(6):
#         ax.scatter(trajectories[-1, i, 0], 
#                    trajectories[-1, i, 1], 
#                    trajectories[-1, i, 2],
#                    color='black', s=50)
#         ax.text(trajectories[-1, i, 0], 
#                 trajectories[-1, i, 1], 
#                 trajectories[-1, i, 2],
#                 f'  {Planet_names[i]}')
    
#     ax.set_xlabel('x [AU]')
#     ax.set_ylabel('y [AU]')
#     ax.set_zlabel('z [AU]')
#     ax.set_title(title)
#     plt.show()


######################################### TASK 2 #############################################

def yoshida_step(p,q,h,masses, G):
    
    gamma_1 = 1.0/(2.0 - 2.0**(1.0/3.0))
    gamma_2 = 1.0 - 2.0 * gamma_1
    gamma_3 = gamma_1
    
    p, q = stormer_verlet(p, q, h*gamma_1, masses, G) # first step
    p, q = stormer_verlet(p, q, h*gamma_2, masses, G) # second step
    p, q = stormer_verlet(p, q, h*gamma_3, masses, G) # third step
    return p,q

def discrete_gradient(p,q,h,masses, G):
    n = len(masses)
    
    def F(x_flat):
        p_new = x_flat[:n*3].reshape(n,3)
        q_new = x_flat[n*3:].reshape(n,3)
        
        p_mid = (p + p_new) / 2 # mid point
        q_mid = (q + q_new) / 2
        
        dp_mid = Compute_Acc(q_mid, masses, G) # discrete gradient at mid point
        dq_mid = compute_Vel(p_mid, masses)
        
        F_p = p_new - p - h * dp_mid
        F_q = q_new - q - h * dq_mid
        
        return np.concatenate([F_p.flatten(), F_q.flatten()])
    
    p_guess, q_guess = stormer_verlet(p, q, h, masses, G)
    x0 = np.concatenate([p_guess.flatten(), q_guess.flatten()])
    
    x_sol, _ = NEWTON(F, x0, TOL = 1e-8, MAX_ITER=100)
    
    p_new = x_sol[:n*3].reshape(n,3)
    q_new = x_sol[n*3:].reshape(n,3)
    
    return p_new, q_new

##################### TASK 3 #################################################
        
def Hamiltonian(p,q, masses, G):
    kinetic = 0.0
    potential = 0.0
    n = len(masses)
    for i in range(n):
        kinetic += np.sum(p[i]**2)/(2*masses[i]) # sum of kinetic energy
        for j in range(i+1,n): # loop over pairs, to void double count
            r = np.linalg.norm(q[i]-q[j]) # euclidian distance between bodies
            potential -= G*masses[i]*masses[j]/r
        
    return kinetic + potential # total hamiltoniam
    
def Simulate_final(method,h,T_final,p0,q0, masses, G):
    n_steps = int(T_final/h)
    p = p0.copy()
    q = q0.copy()
    
    for _ in range(n_steps):
        p, q = method(p,q,h,masses,G)
    return p,q

def Simulate_with_energy(method,h,T_final,p0,q0, masses, G):
    n_steps = int(T_final/h)+1 # total number of steps
    p,q = p0.copy(), q0.copy() # copy the initial state
    
    times = np.zeros(n_steps)
    energy = np.zeros(n_steps)
    
    for i in range(n_steps):
        times[i] = i*h
        energy[i] = Hamiltonian(p, q, masses, G) # energy at the currently state
        if i < n_steps -1:
            p, q = method(p,q,h,masses, G) # advances one step in time
    return times, energy

def energy_conservation_plot(methods, labels, h,T,p0,q0,masses,G):
    fig, axes = plt.subplots(2,3,figsize=(16,10))
    axes = axes.flatten()
    
    for idx, (method, label) in enumerate(zip(methods, labels)):
        print(f'\nSImulating {label} for energy...')
        times, energies = Simulate_with_energy(method, h, T, p0, q0, masses, G)
        
        H0 = energies[0]
        relative_error = (energies - H0)/abs(H0)
        
        axes[idx].plot(times, relative_error, linewidth=1)
        axes[idx].set_xlabel('Time [Days]')
        axes[idx].set_ylabel('Relative Energy Error')
        axes[idx].set_title(f'{label}, h={h}')
        axes[idx].grid(True, alpha=0.3)
        axes[idx].ticklabel_format(style='sci', axis='y',scilimits=(0,0))

    plt.tight_layout()
    return fig

def time_reversibility_test(methods, labels, h_values,n_steps, p0, q0, masses, G):
    
    def time_reversal(p,q):
        return -p, q
    
    print("\nReversibility time")
    print(f"Number of forward/backward steps: {n_steps}")
    
    fig, ax = plt.subplots(figsize=(10,7))
    for method, label in zip(methods, labels):
        print(f'\n{label}:')
        
        errors = []
        
        for h in h_values:
            # Initial state
            p, q = p0.copy(), q0.copy()
            
            # n forward steps
            for _ in range(n_steps):
                p, q = method(p, q, h, masses, G)
            
            # Temporal reversion
            p, q = time_reversal(p, q)
            
            # nn forward steps (= time traveling (Joke))
            for _ in range(n_steps):
                p, q = method(p, q, h, masses, G)
            
            # Time reversal
            p, q = time_reversal(p, q)
            
            error = np.linalg.norm(np.concatenate([p.flatten(), q.flatten()]) - np.concatenate([p0.flatten(), q0.flatten()]))
            
            errors.append(error)
            print(f" H = {h:6.1f}: error = {error:.3e}")
            
        ax.loglog(h_values, errors, 'o-', label=label, linewidth=2,markersize=6)
        
    ax.axhline(y=np.finfo(float).eps, color='red', linestyle='--',linewidth=2, label=f'Machine Precision')
    
    ax.set_xlabel('Step size h')
    ax.set_ylabel('Reversibility Erros')
    ax.set_title(f'Time Reversibility Test (n={n_steps} steps)', fontsize=14)
    ax.grid(True, which='both', alpha = 0.3)
    ax.legend()
    plt.tight_layout()
    
    return fig
      
def reference_solutions(T, p0, q0):
    n = len(masses)
    y0 = np.concatenate([p0.flatten(), q0.flatten()])
    
    def system_ode(t, y):
        p = y[:n*3].reshape(n, 3)
        q = y[n*3:].reshape(n, 3)
        
        dp = Compute_Acc(q, masses, G)
        dq = compute_Vel(p, masses)
        
        return np.concatenate([dp.flatten(), dq.flatten()])
    
    sol = solve_ivp(system_ode, (0, T), y0,
                    method='DOP853',
                    rtol=1e-12, atol=1e-14)
    
    q_ref = sol.y[n*3:, -1].reshape(n, 3)
    return q_ref
  
# def reference_solutions(T,p0,q0):
#     h_ref = 2**(-7) # small tep for the reference solution
#     _, q_ref = Simulate_final(yoshida_step, h_ref, T, p0, q0, masses, G) # use the higher order method to the reference solution
#     return q_ref # return the final position

def global_position_error(method,h,T,p0,q0,q_ref):
    _ , q_num = Simulate_final(method, h, T, p0, q0,masses, G)
    return np.linalg.norm(q_num - q_ref) # global error

def order_plot_all(methods, labels, k_max, T, p0, q0):
    q_ref = reference_solutions(T, p0, q0) # calculate the reference solution
    plt.figure()
    
    total_sims = len(methods)*k_max
    sim_count = 0
    
    for method, label in zip(methods, labels): # loop over all methods
        hs = [] # step list
        errors = [] # errors list
        
        print(f"\n{'='*50}")
        print(f"Method: {label}")
        print(f"{'='*50}")
        
        for k in range(1,k_max+1):
            sim_count += 1
            h = 2**(-k)
            n_steps = int(T/h)
            print(f"  [{sim_count}/{total_sims}] k={k}, h={h:.6f}, steps={n_steps}... ", end='', flush=True)
            
            err = global_position_error(method, h, T, p0, q0, q_ref) # global error
            hs.append(h)
            errors.append(err)
            
            print(f"✓ error={err:.3e}")
        
        plt.loglog(hs, errors, 'o-', label = label)
        
    h_ref = np.array([hs[0],hs[-1]])
    
    plt.loglog(h_ref, h_ref*errors[0]/hs[0], '--', color='gray', alpha=0.5, label="Order 1")
    plt.loglog(h_ref, (h_ref**2)*errors[0]/(hs[0]**2), '--', color='gray', alpha=0.5, label="Order 2")
    plt.loglog(h_ref, (h_ref**4)*errors[0]/(hs[0]**4), '--', color='gray', alpha=0.5, label="Order 4")
    
    plt.xlabel('h',fontsize=12)
    plt.ylabel('Global Error',fontsize=12)    
    plt.title('Convergence Order plot', fontsize = 14)
    plt.grid(True, which='both',alpha=0.3)
    plt.legend()
    
if __name__ == "__main__":
    
    T_final = 200000
    
    fig1, axes1 = plt.subplots(2,2,figsize=(14,12))
    axes1 = axes1.flatten()
    
    print("\n1. Explicit Euler")
    
    traj1 = Simulate(explicita_Euler, h = 10, T_final = T_final, p0=p_init, q0 = q_init, masses=masses, G=G)
    plot_trajectories(traj1, 'Explicit Euler, h = 10', axes1[0])
    
    print("\n2. Implicit Euler")
    
    traj2 = Simulate(implicit_Euler, h = 10, T_final = 100, p0=p_init, q0 = q_init, masses=masses, G=G)
    plot_trajectories(traj2, 'Implicit Euler, h = 10', axes1[1])
    
    print("\n3. Symplectic Euler")
    
    traj3 = Simulate(Symplectic_Euler, h = 100, T_final = T_final, p0=p_init, q0 = q_init, masses=masses, G=G)
    plot_trajectories(traj3, 'Symplectic Euler, h = 100', axes1[2])
    
    print("\n1. Stormer-Verlet")
    
    traj4 = Simulate(stormer_verlet, h = 200, T_final = T_final, p0=p_init, q0 = q_init, masses=masses, G=G)
    plot_trajectories(traj4, 'Stormer-Verlet, h = 200', axes1[3])
    
    plt.tight_layout()
    
    ############### TASK 2 #####################
    
    fig2, axes2 = plt.subplots(1,2,figsize=(14,12))
    axes2 = axes2.flatten()
    
    print("\n1. Yoshida Method")
    
    traj5 = Simulate(yoshida_step, h = 100, T_final = T_final, p0=p_init, q0 = q_init, masses=masses, G=G)
    plot_trajectories(traj5, 'Yoshida Method, h = 100', axes2[0])
    
    print("\n2. IDIscrete Gradient Method")
    
    traj6 = Simulate(discrete_gradient, h = 100, T_final = T_final, p0=p_init, q0 = q_init, masses=masses, G=G)
    plot_trajectories(traj6, 'Discrete Gradient, h = 100', axes2[1])
    
    plt.tight_layout()
    
    #################### TASK 3 #################################################
    
    methods = [
        explicita_Euler,
        implicit_Euler,
        Symplectic_Euler,
        stormer_verlet,
        yoshida_step,
        discrete_gradient
        ]
    labels = [
        'explicite_Euler',
        'implicit_Euler',
        'Symplectic_Euler',
        'stormer_verlet',
        'yoshida_step',
        'discrete_gradient'
        ]
    
    print("\n1. Order plot")
    order_plot_all(methods, labels, k_max=7,T=5000, p0=p_init, q0=q_init)
    plt.tight_layout()
    
    print("\n2. Energy conservation")
    fig_energy = energy_conservation_plot(methods, labels, h=100, T=200000, p0=p_init, q0=q_init, masses=masses, G=G)
    
    print("\n3. Time reversibility")
    h_values = [100,50,25,10,5,1]
    n_steps = 100
    fig_rev = time_reversibility_test(methods, labels, h_values,n_steps, p0=p_init, q0=q_init, masses=masses, G=G)